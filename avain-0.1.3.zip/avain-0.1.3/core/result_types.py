from enum import Enum

class ResultType(Enum):
    SCAN = "SCAN"
    VULN_SCORE = "VULN_SCORE"
    WEBSERVER_MAP = "WEBSERVER_MAP"
